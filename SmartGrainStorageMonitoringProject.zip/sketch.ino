#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <WiFi.h>
#include <HTTPClient.h>

// WiFi Credentials
const char* ssid = "Wokwi-GUEST";
const char* password = "";

String firebaseURL = "https://sgsm-f4dc1-default-rtdb.firebaseio.com/GrainStorage.json";

String status;
String fanStatus;

// DHT22
#define DHTPIN 15
#define DHTTYPE DHT22

// Ultrasonic
#define TRIG_PIN 5
#define ECHO_PIN 18

// Outputs
#define GREEN_LED 12
#define RED_LED 13
#define BUZZER 27
#define RELAY 26

DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {

  Serial.begin(115200);

  // Connect WiFi
  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  dht.begin();

  lcd.init();
  lcd.backlight();

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  pinMode(RELAY, OUTPUT);

  digitalWrite(GREEN_LED, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(BUZZER, LOW);
  digitalWrite(RELAY, LOW);
}

// Function to read distance
float readDistanceCM() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH);

  float distance = duration * 0.0343 / 2.0;

  return distance;
}

void loop() {

  // Read Sensors
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  float distance = readDistanceCM();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("DHT Error");
    delay(2000);
    return;
  }

  // Calculate Grain Level
  int grainLevel = map((int)distance, 100, 0, 0, 100);
  grainLevel = constrain(grainLevel, 0, 100);

  // Alert Logic
  bool alert = false;

  if (temperature > 35)
    alert = true;

  if (humidity > 70)
    alert = true;

  if (grainLevel < 20)
    alert = true;

  if (alert) {

    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
    digitalWrite(BUZZER, HIGH);
    digitalWrite(RELAY, HIGH);

    status = "ALERT";
    fanStatus = "ON";

  } else {

    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
    digitalWrite(BUZZER, LOW);
    digitalWrite(RELAY, LOW);

    status = "SAFE";
    fanStatus = "OFF";
  }

  // Serial Monitor
  Serial.println("-------------------------");
  Serial.print("Temperature : ");
  Serial.print(temperature);
  Serial.println(" C");

  Serial.print("Humidity : ");
  Serial.print(humidity);
  Serial.println(" %");

  Serial.print("Distance : ");
  Serial.print(distance);
  Serial.println(" cm");

  Serial.print("Grain Level : ");
  Serial.print(grainLevel);
  Serial.println(" %");

  Serial.print("Status : ");
  Serial.println(status);

  Serial.print("Fan : ");
  Serial.println(fanStatus);

  // LCD Display
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(temperature, 1);
  lcd.print("C");

  lcd.setCursor(9, 0);
  lcd.print("H:");
  lcd.print((int)humidity);

  lcd.setCursor(0, 1);
  lcd.print("G:");
  lcd.print(grainLevel);
  lcd.print("% ");

  if (alert)
    lcd.print("ALERT");
  else
    lcd.print("SAFE");

  // Upload to Firebase
  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;

    http.begin(firebaseURL);

    http.addHeader("Content-Type", "application/json");

    String json = "{";
    json += "\"Temperature\":" + String(temperature, 1) + ",";
    json += "\"Humidity\":" + String(humidity, 1) + ",";
    json += "\"GrainLevel\":" + String(grainLevel) + ",";
    json += "\"Status\":\"" + status + "\",";
    json += "\"Fan\":\"" + fanStatus + "\"";
    json += "}";

    int httpResponseCode = http.PUT(json);

    Serial.print("Firebase Response: ");
    Serial.println(httpResponseCode);

    if (httpResponseCode > 0) {
      Serial.println("Data Uploaded Successfully");
    } else {
      Serial.println("Upload Failed");
    }

    http.end();

  } else {

    Serial.println("WiFi Disconnected");

  }

  delay(5000);
}